$(document).ready(function(){
	$('.slider').owlCarousel({
	    loop:true,
	    margin:10,
	    responsiveClass:true, 
    	autoplay: true,
    	autoplayTimeout: 5000,
    	navText:['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
    	smartSpeed: 450, 
    	animateOut: 'fadeOut',
    	animateIn: 'fadeIn',
	    nav:true,
	    dots: false,
	    responsive:{
	        0:{
	            items:1,
	        },
	        600:{
	            items:1,
	        },
	        1000:{
	            items:1,
	        }
	    }
	});
	$('.testimonial').owlCarousel({
	    loop:true,
	    margin:0,
	    responsiveClass:true, 
    	autoplay: true,
    	autoplayTimeout: 5000,
    	smartSpeed: 450, 
	    nav:false,
	    dots: false,
	    responsive:{
	        0:{
	            items:1,
	        },
	        600:{
	            items:1,
	        },
	        1000:{
	            items:1,
	        }
	    }
	});
	$('.clients').owlCarousel({
	    loop:true,
	    margin:0,
	    responsiveClass:true, 
    	autoplay: true,
    	autoplayTimeout: 5000,
    	smartSpeed: 450, 
	    nav:false,
	    dots: false,
	    responsive:{
	        0:{
	            items:1,
	        },
	        600:{
	            items:3,
	        },
	        1000:{
	            items:7,
	        }
	    }
	});
	

	 $('.isotop-item').isotope({
        itemSelector: '.item',
        LayoutMode: 'fitRows'
    });
    $('.isotop ul li').on('click', function(e){
        $('.isotop ul li').removeClass('active');
        $(this).addClass('active');
        
        var selector = $(this).attr('data-filter');
        $('.isotop-item').isotope({
            filter: selector
        });
        return false;
    });

    $('.counter').counterUp({
        delay: 10,
        time: 1000,
    });


    $('.scrollup').on('click', function(e){
        $('html').animate({
            'scrollTop':0
        },1000);
        return false;
    });
    $(window).scroll(function(){
        var halcyan = $(window).scrollTop();
        if(halcyan>400){
            $('.scrollup').slideDown(1000);
        }
        else{
            $('.scrollup').slideUp(1000);
        }

    });


});


